#!/system/bin/sh
echo "挂载分区"
mount -o remount -rw  /system
busybox mount -o remount -rw  /system
chmod 0755 /system/xbin/*
busybox chmod 0755 /system/xbin/*
# wlan配置文件位置
find /vendor/etc/wifi/* -name "WCNSS_qcom_cfg.ini" > /data/media/0/Rulong/Wlan配置文件位置.log
